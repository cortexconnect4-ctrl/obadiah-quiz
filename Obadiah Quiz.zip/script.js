const questions = [
{
question:"1. ఓబద్యా ప్రవక్త ఏ జాతికి వ్యతిరేకంగా ప్రవచించాడు?",
answers:[
{text:"ఏదోము",correct:true},
{text:"మోయాబు",correct:false},
{text:"అమ్మోను",correct:false},
{text:"అస్సూరు",correct:false}
]
},
{
question:"2. ఓబద్యా గ్రంథంలో ఎన్ని అధ్యాయాలు ఉన్నాయి?",
answers:[
{text:"1",correct:true},
{text:"2",correct:false},
{text:"3",correct:false},
{text:"4",correct:false}
]
},
{
question:"3. ఏదోము పాపానికి ప్రధాన కారణం ఏమిటి?",
answers:[
{text:"గర్వము",correct:true},
{text:"విగ్రహారాధన",correct:false},
{text:"అబద్ధము",correct:false},
{text:"దొంగతనం",correct:false}
]
},
{
question:"4. ఏదోము ఎవరి సంతానం?",
answers:[
{text:"ఏశావు",correct:true},
{text:"యాకోబు",correct:false},
{text:"ఇస్సాకు",correct:false},
{text:"అబ్రాహాము",correct:false}
]
},
{
question:"5. యెహోవా దినము ఎవరి మీద సమీపమై ఉంది?",
answers:[
{text:"అన్ని జనముల మీద",correct:true},
{text:"ఇశ్రాయేలు మీద మాత్రమే",correct:false},
{text:"యూదా మీద మాత్రమే",correct:false},
{text:"ఏదీ కాదు",correct:false}
]
},
{
question:"6. దేవుడు ఎవరిని హెచ్చరించాడు?",
answers:[
{text:"ఏదోము",correct:true},
{text:"ఫిలిష్తీయులు",correct:false},
{text:"ఈజిప్టు",correct:false},
{text:"బాబులోను",correct:false}
]
},
{
question:"7. ఏదోము ఎక్కడ నివసించేవారు?",
answers:[
{text:"పర్వత ప్రాంతాల్లో",correct:true},
{text:"సముద్రతీరంలో",correct:false},
{text:"అరణ్యంలో",correct:false},
{text:"లోయలో",correct:false}
]
},
{
question:"8. ఓబద్యా గ్రంథం ప్రధాన సందేశం ఏమిటి?",
answers:[
{text:"గర్వానికి తీర్పు",correct:true},
{text:"సృష్టి",correct:false},
{text:"ధర్మశాస్త్రం",correct:false},
{text:"బాప్తిస్మము",correct:false}
]
},
{
question:"9. చివరికి రాజ్యం ఎవరిది?",
answers:[
{text:"యెహోవాదే",correct:true},
{text:"ఏదోముదే",correct:false},
{text:"బాబులోనుదే",correct:false},
{text:"అస్సూరుదే",correct:false}
]
},
{
question:"10. ఓబద్యా గ్రంథం ఏ నిబంధనలో ఉంది?",
answers:[
{text:"పాత నిబంధన",correct:true},
{text:"కొత్త నిబంధన",correct:false},
{text:"కీర్తనలు",correct:false},
{text:"సామెతలు",correct:false}
]
}
, 
{
question:"11. ఓబద్యా గ్రంథ రచయిత ఎవరు?",
answers:[
{text:"ఓబద్యా",correct:true},
{text:"యోయేలు",correct:false},
{text:"ఆమోసు",correct:false},
{text:"హగ్గయి",correct:false}
]
},
{
question:"12. 'ఓబద్యా' అనే పేరుకు అర్థం ఏమిటి?",
answers:[
{text:"యెహోవా సేవకుడు",correct:true},
{text:"శాంతి రాజు",correct:false},
{text:"దేవుని దూత",correct:false},
{text:"ప్రవక్త",correct:false}
]
},
{
question:"13. ఏదోము ప్రజలు ఎవరికి సహోదరులు?",
answers:[
{text:"ఇశ్రాయేలీయులు",correct:true},
{text:"ఫిలిష్తీయులు",correct:false},
{text:"అస్సూరీయులు",correct:false},
{text:"మిద్యానీయులు",correct:false}
]
},
{
question:"14. ఏదోము పతనానికి కారణమైన లక్షణం ఏది?",
answers:[
{text:"గర్వం",correct:true},
{text:"ప్రేమ",correct:false},
{text:"సహనం",correct:false},
{text:"దయ",correct:false}
]
},
{
question:"15. ఏదోము తన నివాస స్థలంపై ఎలా భావించింది?",
answers:[
{text:"ఎవరూ మమ్మల్ని దించలేరు",correct:true},
{text:"మేము బలహీనులము",correct:false},
{text:"మాకు సహాయం కావాలి",correct:false},
{text:"మేము పారిపోతాము",correct:false}
]
},
{
question:"16. దేవుడు ఏదోమును దేనితో పోల్చాడు?",
answers:[
{text:"గద్ద",correct:true},
{text:"సింహం",correct:false},
{text:"పావురం",correct:false},
{text:"గొర్రె",correct:false}
]
},
{
question:"17. ఏదోము తన గూడు ఎక్కడ కట్టుకున్నట్లు చెప్పబడింది?",
answers:[
{text:"నక్షత్రాల మధ్య",correct:true},
{text:"సముద్రంలో",correct:false},
{text:"అరణ్యంలో",correct:false},
{text:"లోయలో",correct:false}
]
},
{
question:"18. దొంగలు వస్తే ఏమి మిగులుస్తారు?",
answers:[
{text:"కొంత మిగులుస్తారు",correct:true},
{text:"ఏమీ మిగల్చరు",correct:false},
{text:"అన్నీ తిరిగి ఇస్తారు",correct:false},
{text:"బంగారం మాత్రమే తీసుకుంటారు",correct:false}
]
},
{
question:"19. ద్రాక్ష కోయువారు ఏమి వదిలివెళ్తారు?",
answers:[
{text:"కొన్ని ద్రాక్షపండ్లు",correct:true},
{text:"ఏవీ కాదు",correct:false},
{text:"విత్తనాలు",correct:false},
{text:"ఆకులు",correct:false}
]
},
{
question:"20. ఏదోము ధనము ఏమవుతుంది?",
answers:[
{text:"వెదకబడుతుంది",correct:true},
{text:"పెరుగుతుంది",correct:false},
{text:"దాచబడుతుంది",correct:false},
{text:"దానం చేయబడుతుంది",correct:false}
]
},
{
question:"21. ఏదోము మిత్రులు ఏమి చేస్తారు?",
answers:[
{text:"మోసం చేస్తారు",correct:true},
{text:"రక్షిస్తారు",correct:false},
{text:"స్తుతిస్తారు",correct:false},
{text:"గౌరవిస్తారు",correct:false}
]
},
{
question:"22. దేవుడు ఏదోము జ్ఞానులను ఎక్కడి నుండి నాశనం చేస్తాడు?",
answers:[
{text:"తేమాను",correct:true},
{text:"యెరూషలేము",correct:false},
{text:"సీయోను",correct:false},
{text:"బాబులోను",correct:false}
]
},
{
question:"23. తేమాను దేనికి ప్రసిద్ధి?",
answers:[
{text:"జ్ఞానులకు",correct:true},
{text:"బంగారానికి",correct:false},
{text:"దేవాలయానికి",correct:false},
{text:"పశువులకు",correct:false}
]
},
{
question:"24. ఏదోము వీరులు ఎలా అవుతారు?",
answers:[
{text:"భయపడతారు",correct:true},
{text:"విజయిస్తారు",correct:false},
{text:"ఆనందిస్తారు",correct:false},
{text:"పరుగెడతారు",correct:false}
]
},
{
question:"25. ఏదోము శిక్షకు ప్రధాన కారణం ఏమిటి?",
answers:[
{text:"యాకోబుపై చేసిన హింస",correct:true},
{text:"కరువు",correct:false},
{text:"వ్యాధి",correct:false},
{text:"పన్నులు",correct:false}
]}];

const startScreen = document.getElementById("startScreen");
const startBtn = document.getElementById("startBtn");
const playerName = document.getElementById("playerName");

const quiz = document.getElementById("quiz");
const questionElement = document.getElementById("question");
const answersElement = document.getElementById("answers");
const nextButton = document.getElementById("nextBtn");const timerElement = document.getElementById("timer");
let timer;

let currentQuestion = 0;
let score = 0;
let player = "";

startBtn.onclick = function () {
  if (playerName.value.trim() === "") {
    alert("దయచేసి మీ పేరు నమోదు చేయండి");
    return;
  }

  player = playerName.value;
  startScreen.style.display = "none";
  quiz.style.display = "block";
  startQuiz();
};
 function startQuiz() {
  currentQuestion = 0;
  score = 0;
  nextButton.innerHTML = "Next";
  showQuestion();
}

function showQuestion() {
  
  answersElement.innerHTML = "";
  nextButton.style.display = "none";

  let q = questions[currentQuestion];
  questionElement.innerHTML = q.question;
document.getElementById("progress").innerHTML =
(currentQuestion + 1) + " / " + questions.length;
  q.answers.forEach(answer => {
    const button = document.createElement("button");
    button.className = "btn";
    button.innerHTML = answer.text;

    button.onclick = function () {
      if (answer.correct) {
        score++;
        alert("✅ సరైన సమాధానం");
      } else {
        alert("❌ తప్పు సమాధానం");
      }
      nextButton.style.display = "block";
    };

    answersElement.appendChild(button);
  });
}

nextButton.onclick = function () {
  currentQuestion++;

  if (currentQuestion < questions.length) {
    showQuestion();
  } else {
    questionElement.innerHTML =
      `🎉 ${player}<br><br>మీ స్కోర్: ${score}/${questions.length}`;

    answersElement.innerHTML = "";
    nextButton.style.display = "none"
  }
};